// extracted inline script
(function(){
self.__next_f.push([1,"11:{\"metadata\":[[\"$\",\"title\",\"0\",{\"children\":\"RGBang\"}],[\"$\",\"meta\",\"1\",{\"name\":\"description\",\"content\":\"A vibrant, fast-paced arcade shooter built with Next.js and Canvas.\"}]],\"error\":null,\"digest\":\"$undefined\"}\nb:{\"metadata\":\"$11:metadata\",\"error\":null,\"digest\":\"$undefined\"}\n"])
})();
