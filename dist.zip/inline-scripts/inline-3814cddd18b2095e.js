// extracted inline script
(function(){
(self.__next_f=self.__next_f||[]).push([0])
})();
