// extracted inline script
(function(){
self.__next_f.push([1,"1:\"$Sreact.fragment\"\n2:I[7555,[],\"\"]\n3:I[1295,[],\"\"]\n4:I[1459,[\"802\",\"static/chunks/802-d69ef10db5f70343.js\",\"177\",\"static/chunks/app/layout-8e47e2d249d6cd38.js\"],\"Toaster\"]\n5:I[894,[],\"ClientPageRoot\"]\n6:I[2726,[\"802\",\"static/chunks/802-d69ef10db5f70343.js\",\"38\",\"static/chunks/38-6cc9fa4c8b4df39e.js\",\"974\",\"static/chunks/app/page-ff8779c435471aa8.js\"],\"default\"]\n9:I[9665,[],\"MetadataBoundary\"]\nb:I[9665,[],\"OutletBoundary\"]\ne:I[4911,[],\"AsyncMetadataOutlet\"]\n10:I[9665,[],\"ViewportBoundary\"]\n12:I[6614,[],\"\"]\n:HL[\"./next-assets/static/css/43044b6aa3a246b8.css\",\"style\"]\n"])
})();
